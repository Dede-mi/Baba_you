"""6.009 Lab 10: Snek Is You Video Game"""

import doctest

# NO ADDITIONAL IMPORTS!

# All words mentioned in lab. You can add words to these sets,
# but only these are guaranteed to have graphics.
NOUNS = {"SNEK", "FLAG", "ROCK", "WALL", "COMPUTER", "BUG"}
PROPERTIES = {"YOU", "WIN", "STOP", "PUSH", "DEFEAT", "PULL"}
WORDS = NOUNS | PROPERTIES | {"AND", "IS"}

# Maps a keyboard direction to a (delta_row, delta_column) vector.
direction_vector = {
    "up": (-1, 0),
    "down": (+1, 0),
    "left": (0, -1),
    "right": (0, +1),
}

reverse_direction_vector = {
    "down": "up",
    "up": "down",
    "right": "left",
    "left": "right",
}


############
#Create Classes###
#############

class game:
    def __init__(self, game_desc):
        self.width = len(game_desc[0]) #assuming all rows are evenly spaced
        self.height = len(game_desc)
        
        objects, rules = init_entities(game_desc)
        
        self.objects = objects
        self.rules = rules
        self.you = []
        
    def is_valid_space(self, space):
        """
        checks if place can be moved to where space is a tuple representing a location
        """
        if isinstance(space[0], int) and (space[0] > -1) and space[0] < self.height:
            if isinstance(space[1], int) and (space[1] > -1) and space[1] < self.width:
                return True

        return False
    def reset_rules (self):
        self.you = []
        for N in NOUNS:
            noun = N.lower()
            self.objects[noun].stop = False
            self.objects[noun].pull = False
            self.objects[noun].push = False
            self.objects[noun].win = False
            self.objects[noun].defeat = False
            self.objects[noun].you = False
            

    def evaluate_rules(self, go = False):
        
        self.reset_rules()
        dict_rules = {
        "snek": [],
        "wall": [],
        "rock": [],
        "computer": [],
        "bug": [],
        "flag": []}
        
        for erule in self.rules:
            tokenized = erule.split()
            if not (tokenized[0] in NOUNS  or (tokenized[2] in PROPERTIES or tokenized[2] in NOUNS)):
                continue
            dict_rules[tokenized[0].lower()].append(tokenized[2])

        #create a replica environment
        testenv.width = self.width
        testenv.height = self.height
        testenv.objects, testenv.rules = self.objects.copy(), self.rules.copy()
        testenv.you = self.you

        keep_flag = []
        keep_bug = []
        keep_snek = []
        keep_computer = []
        keep_rock = []
        keep_wall = []
        make_empty = []
            
        for objval in dict_rules:
            if set(self.objects[objval].current_rules) == set(dict_rules[objval]):
                continue
            self.objects[objval].stop = self.objects[objval].push = self.objects[objval].pull = self.objects[objval].win  = self.objects[objval].defeat = False
            for orule in dict_rules[objval]:
                if orule == "YOU":
                    self.objects[objval].you = True
                    self.you.append(objval)
                if orule == "STOP":
                    self.objects[objval].stop = True
                if orule == "PUSH":
                    self.objects[objval].push = True
                if orule == "PULL":
                    self.objects[objval].pull = True
                if orule == "WIN":
                    self.objects[objval].win = True
                if orule == "DEFEAT":
                    self.objects[objval].defeat = True
                if orule == "SNEK":
                    keep_snek.extend(self.objects[objval].locations)
                    make_empty.append(objval)
                if orule == "WALL":
                    keep_wall.extend(self.objects[objval].locations)
                    make_empty.append(objval)
                if orule == "ROCK":
                    keep_rock.extend(self.objects[objval].locations)
                    make_empty.append(objval)
                if orule == "COMPUTER":
                    keep_computer.extend(self.objects[objval].locations)
                    make_empty.append(objval)
                if orule == "BUG":
                    keep_bug.extend(self.objects[objval].locations)
                    make_empty.append(objval)
                if orule == "FLAG":
                    keep_flag.extend(self.objects[objval].locations)
                    make_empty.append(objval)

        if go:

            for emp in make_empty:
                self.objects[emp].locations = []
                if emp in self.objects['inplay']:
                    self.objects['inplay'].remove(emp)
            
            if  keep_flag:
                self.objects['inplay'].add("flag")
                self.objects["flag"].locations.extend(keep_flag)
            if  keep_bug:
                self.objects['inplay'].add("bug")
                self.objects["bug"].locations.extend(keep_bug)
            if  keep_computer:
                self.objects['inplay'].add("computer")
                self.objects["computer"].locations.extend(keep_computer)
            if  keep_snek:
                self.objects['inplay'].add("snek")
                self.objects["snek"].locations.extend(keep_snek)
            if  keep_wall:
                self.objects['inplay'].add("wall")
                self.objects["wall"].locations.extend(keep_wall)
            if  keep_rock:
                self.objects['inplay'].add("rock")
                self.objects["rock"].locations.extend(keep_rock)
                    
            
            #idea for optimization: store the rules that are currently being followed
            #if it differs at all, change accordingly

        return self.rules
    
    def update_state(self, direction):
        moved_col = []
        possible_locs= {}

        for Y in self.you:
            old_you = self.objects[Y].locations
            
            possible_you_locations = self.update_any_token(direction, Y)
            possible_locs[Y] = possible_you_locations
            mobile_to_push = set()
            
        for Y in self.you:

            for count, loc in enumerate(possible_locs[Y]): #consider each place you wants to move - the goal
                barriers = []
                if possible_locs[Y][count] == self.objects[Y].locations[count]:
                    continue
                for obj in self.objects["inplay"]: #querry all tokens currently in the game
                    if loc in self.objects[obj].locations: #if you find the location in a specific token
                        barriers.append(obj)
                if barriers ==[]:
                    #move you
                    self.objects[Y].locations[count] = loc
                    
                    continue
                moveable = True
                for bar in barriers:
                    if not self.move_without_consequence(bar, loc, direction):
                        moveable = False
                        break #move on to next you is eer not possible, move on to the next you
                if moveable == False:
                    continue
                
                #if everyone returns true, then move the barrier and the token
                for bar in barriers:
                    falseornone = self.move_token(bar, loc, direction)
                    if falseornone:
                        mobile_to_push.add(loc)
                #move you
                self.objects[Y].locations[count] = loc

            moved = self.update_pull(mobile_to_push, direction, False)

            self.pull_extended(moved, direction)

            moved_col = moved_col + moved

        return [value[1] for value in moved_col] #moved is a list of tuples containing (stuff, where is now)
        

            #update the rules
            #self.update_rules()
            #self.evaluate_rules()
    def update_rules(self):

        horizontal = set()
        vertical = set()

        h_ret = self.eval_direction(True)
        v_ret = self.eval_direction(False)

        if h_ret:
            horizontal = h_ret
        if v_ret:
            vertical = v_ret

        self.rules = horizontal.union(vertical)
        
        #self.rules = ["SNEK IS YOU", "COMPUTER IS PUSH", "WALL IS STOP"]
        
    def eval_direction(self, orient):
        """
            True = horizontal
            False = vertical
        """
        order = None
        if orient:
            order = ("left", "right")
        else:
            order = ("up", "down")

        new_rules = set()
            

        find_nouns = []
        find_properties = []
        
        consider = self.objects["IS"].locations

        #find on left
        for con in consider:
            find_nouns = []
            find_properties = []
            new_loc = self.find_loc(order[0], con)
            if new_loc == con:
                continue
            else:
                for obj in NOUNS: #querry all nouns possible
                    if obj in self.objects["inplay"]:
                        if new_loc in self.objects[obj].locations: #if you find the location in a specific token
                            find_nouns.append(obj)
                            possibly_more = True
                            new_new_loc = self.find_loc(order[0], new_loc)
                            if new_new_loc != new_loc:
                                if new_new_loc in self.objects["AND"].locations:
                                    while possibly_more:
                                        possibly_more = False
                                        new_loc = self.find_loc(order[0], new_new_loc)
                                        for obj in NOUNS: #querry all nouns possible
                                            if obj in self.objects["inplay"]:
                                                if new_loc in self.objects[obj].locations: #if you find the location in a specific token
                                                    find_nouns.append(obj)
                                                    new_new_loc = self.find_loc(order[0], new_loc)
                                                    if new_new_loc != new_loc:
                                                        if new_new_loc in self.objects["AND"].locations:
                                                            possibly_more = True
            if not find_nouns:
                continue
            PP = PROPERTIES.copy()
            querry = PP.union(NOUNS)
            #find on right
            new_loc = self.find_loc(order[1], con)
            if new_loc == con:
                pass
            else:
                found_prop = False
                for obj in querry : #querry all nouns possible
                    if obj in self.objects["inplay"]:
                        if new_loc in self.objects[obj].locations: #if you find the location in a specific token
                            found_prop = True
                            find_properties.append(obj)
                            possibly_more = True
                            new_new_loc = self.find_loc(order[1], new_loc)
                            if new_new_loc != new_loc:
                                if new_new_loc in self.objects["AND"].locations:
                                    while possibly_more:
                                        possibly_more = False
                                        new_loc = self.find_loc(order[1], new_new_loc)
                                        for obj in querry: #querry all nouns possible
                                            if obj in self.objects["inplay"]:
                                                if new_loc in self.objects[obj].locations: #if you find the location in a specific token
                                                    find_properties.append(obj)
                                                    new_new_loc = self.find_loc(order[1], new_loc)
                                                    if new_new_loc != new_loc:
                                                        if new_new_loc in self.objects["AND"].locations:

                                                            possibly_more = True

##            new_loc = self.find_loc(order[0], con)
##            if new_loc == con:
##                pass
##            else:
##                for obj in NOUNS: #querry all nouns possible
##                    if obj in self.objects["inplay"]:
##                        if new_loc in self.objects[obj].locations: #if you find a noun in the right place
##                             #try to find another noun in the right place too
##                            new_new_loc = self.find_loc(order[1], con)
##                            if new_new_loc == con:
##                                pass
##                            else:
##                                for obj2 in NOUNS: #querry all nouns possible
##                                    if obj2 in self.objects["inplay"]:
##                                        if new_new_loc in self.objects[obj2].locations:
##                                            new_rules.add(obj+ " IS "+ obj2)
##                                            possibly_more = True
##                                            new_loc = self.find_loc(order[1], new_new_loc)
##                                            if new_loc != new_new_loc:
##                                                if new_loc in self.objects["AND"].locations:
##                                                    while possibly_more:
##                                                        possibly_more = False
##                                                        new_new_loc = self.find_loc(order[1], new_loc)
##                                                        for obj3 in PROPERTIES: #querry all nouns possible
##                                                            if obj3 in self.objects["inplay"]:
##                                                                if new_new_loc in self.objects[obj3].locations: #if you find the location in a specific token
##                                                                    new_rules.add(obj +" IS " + obj3)
##                                                                    new_loc = self.find_loc(order[1], new_new_loc)
##                                                                    if new_new_loc != new_loc:
##                                                                        if new_loc in self.objects["AND"].locations:
##                                                                            possibly_more = True

            
            for N in find_nouns:
                for P in find_properties:
                    new_rules.add(N+ " IS "+ P)
        
        return new_rules
                    

    def find_loc(self, direction, item_loc):

        vector = direction_vector[direction]
        newlocation =(item_loc[0] + vector[0], item_loc[1] + vector[1])
        if self.is_valid_space(newlocation):
            return newlocation
        else:
            return item_loc

        
    def move_token(self, obj, location, direction):
        """
        move this object currently in this location in this direction, (implied one space)
        """
        if self.objects[obj].push == False:
            return False

    
        vector = direction_vector[direction]
        move_to = (location[0] + vector[0], location[1] + vector[1])

        objonsquare = [] #keep track of all objects on the square you are moving to that must be considered
        for objtype in self.objects["inplay"]:
            if move_to in self.objects[objtype].locations:
                 objonsquare.append(objtype)
        
        
        
        #print(self.objects[obj].locations)
        #print(location, move_to)
        self.objects[obj].locations.remove(location)
        self.objects[obj].locations.append(move_to)

        #self.update_pull([location], direction, False)

        for objj in objonsquare:
            if self.objects[objj].push == True:
                self.move_token(objj, move_to, direction)
        return True
            

        
    def move_without_consequence(self, obj, location, direction):
        """
        Move said object in said location to this direction
        """
        #determine if object can move
        if not self.objects[obj].push and self.objects[obj].stop:
            return False
        elif not self.objects[obj].push: #if it does not have to be pushed, then don't worry
            return True
        
        #create replica environment
        
        testenv.width = self.width
        testenv.height = self.height
        testenv.objects, testenv.rules = self.objects.copy(), self.rules.copy()
        testenv.you = self.you

        vector = direction_vector[direction]
        move_to = (location[0] + vector[0], location[1] + vector[1])

        if (self.height -1 < move_to[0]) or (self.width -1 < move_to[1]) or move_to[0] < 0 or move_to[1] < 0:
            return False

        objonsquare = [] #keep track of all objects on the square you are moving to that must be considered
        for objtype in testenv.objects["inplay"]:
            if move_to in testenv.objects[objtype].locations:
                 objonsquare.append(objtype)

        if objonsquare == []:
            return True
        for objj in objonsquare:
            if not testenv.objects[obj].push and testenv.objects[objj].stop == True : #if any cannot be stopped then just dont
                return False
            if not testenv.move_without_consequence(objj, move_to, direction):
                return False
            
        return True
    
        

    def update_any_token(self, direction, token, reverse=False):
        tentlocation = []

        if reverse:
            whereistoken = token
            vector = direction_vector[reverse_direction_vector[direction]]
            
        else:
            whoistoken = token
            whereistoken = self.objects[whoistoken].locations
            vector = direction_vector[direction]
        for locate in whereistoken:
            newlocation =(locate[0] + vector[0], locate[1] + vector[1])
            if self.is_valid_space(newlocation):
                tentlocation.append(newlocation)
            else:
                tentlocation.append(locate)
        return tentlocation

    def update_pull(self, locations_, direction, pulling_you = True, seen = []):
##        if pulling_you:
##            current_loc = self.objects[self.you].locations

##            for loca in locations_:
##                if loca in current_loc:
##                    while loca in locations_:
##                        locations_.remove(loca)
        #print("WELLLLL", seen)
        
        locations_ = list(locations_)
        for locat in locations_:
            for obj in self.objects["inplay"]: #querry all tokens currently in the game
                if locat in self.objects[obj].locations: #if you find the location in a specific token
                    if self.objects[obj].stop == True: #look for obstacles
                        locations_.remove(locat)

        success = []
        vector = direction_vector[direction]
        possible_pull = self.update_any_token(direction, set(locations_), True) #finds all of the tokens that are behind
        for pull in possible_pull:
            if pull in locations_:
                possible_pull.remove(pull)
                
        #print("POSSIBLE PULL", possible_pull)

        pullable = []
        for possible_loc in possible_pull:
            for obj in self.objects["inplay"]: #querry all tokens currently in the game
                if possible_loc in self.objects[obj].locations: #if you find the location in a specific token
                    if self.objects[obj].pull == True: #find out if it's pullable
                        #check if it has other friends to pull
                        
                        for count in range(self.objects[obj].locations.count(possible_loc)): #move as many of that as exists on the tile
                            pullable.append((obj,possible_loc))
                        done = self.update_pull([possible_loc], direction, False, seen)
                        success.extend(done)
        locations_of_you = []
        for Y in self.you:
            locations_of_you += self.objects[Y].locations
        for pullobj in pullable:
            #final check, make sure new locatio isvalid:
            move_to = (pullobj[1][0] + vector[0], pullobj[1][1] + vector[1])
            
            if pullobj[1] in seen:
                continue
            elif move_to in locations_of_you and pulling_you:
                continue
            self.objects[pullobj[0]].locations.remove(pullobj[1]) 
            self.objects[pullobj[0]].locations.append(move_to)

            success.append((pullobj, move_to)) #possible area for improvement : dont querry families of 
        return success
    
    def pull_extended(self, success, direction):
        agenda = []
        impede = set()
        types = set()
        locations = set()
        for i in success:
            types.add(i[0][0])
            locations.add((i[0][1], i[1]))
        for locs in locations:
            for obj in set(self.objects["inplay"])-types: #querry all tokens currently in the game
                if locs[0] in self.objects[obj].locations: #if you find the location in a specific token
                    if self.objects[obj].push == True: #find out if it's pullable
                        if locs[0] in self.objects[obj].locations:
                            for count in range(self.objects[obj].locations.count(locs[0])):
                        #schedule to pull it
                                agenda.append((obj, locs))
                                continue #dont check if impeded
                    if self.objects[obj].stop == True: #find out if it's impeding
                        impede.add(locs[0])
        #could be irrelevant               
        final = []
        for thing in agenda:
            if thing[1][0] not in impede:
                self.objects[thing[0]].locations.remove(thing[1][0]) 
                self.objects[thing[0]].locations.append(thing[1][1])
                final.append(thing[1][0])


        for i in final:
            self.update_pull([i], direction, False)
            
    def determine_defeat(self):
        
        locations_of_you = {}
        for Y in self.you:
            locations_of_you[Y] = set(self.objects[Y].locations)
        for obj in self.objects["inplay"]: #if item on the board
            if self.objects[obj].defeat: #if item has defeat property
                for Y in locations_of_you:
                    intersect = set(self.objects[obj].locations).intersection(locations_of_you[Y])
                    if intersect:
                        for inter in intersect:
                            for count in range(self.objects[Y].locations.count(inter)):
                                self.objects[Y].locations.remove(inter)
                        
##                intersect = locations_of_you.intersection(self.objects[obj].locations)
##                if intersect: #if item has spaces in common
##                    for inter in intersect:
##                        for count in range(self.objects[Y].locations.count(inter)):
##                            self.objects[Y].locations.remove(inter)                    
                    
            
        
    def haswon(self):
        locations_of_you = []
        for Y in self.you:
            locations_of_you += self.objects[Y].locations
        for obj in self.objects["inplay"]: #if item on the board
            if self.objects[obj].win: #if item has win property
                if set(self.objects[obj].locations).intersection(locations_of_you): #if item has spaces in common
                    return True
        return False
        

class allobjects:
    you = False
    stop = False
    push = False
    pull = False
    win  = False
    defeat = False
    current_rules = []
    
    def __init__(self, locate):
        #nothing but common rules
        self.locations = [ point for point in locate]

    def update(self, game):
        pass

    def render(self):
        #print_at_location(*self.position, self.char, self.color)
        pass
    
        

class graphical_object(allobjects):
    def __init__(self, locate):
        super().__init__(locate)
        
    def update(self, game):
        pass


class text_object(allobjects):
    push = True
    
    def __init__(self, locate):
        super().__init__(locate)
        
        
    def update(self, game):
        pass

class Noun(text_object):
    def __init__(self, locate):
        super().__init__(locate)
        
    def update(self, game):
        pass
##        self.ttl -= 1
##        if self.ttl <= 0:
##            self.alive = False

class Property(text_object):
    def __init__(self, locate):
        super().__init__(locate)
        
    def update(self, game):
        pass
##        self.ttl -= 1
##        if self.ttl <= 0:
##            self.alive = False
    
class Verb(text_object):
    def __init__(self, locate):
        super().__init__(locate)
        
    def update(self, game):
        pass
##        self.ttl -= 1
##        if self.ttl <= 0:
##            self.alive = False
        
class Conjunction(text_object):
    def __init__(self, locate):
        super().__init__(locate)
        
    def update(self, game):
        pass
##        self.ttl -= 1
##        if self.ttl <= 0:
##            self.alive = False

def init_entities(game_desc):
    object_dict = {
        "IS": Verb(()),
        "AND": Conjunction(()),
        "SNEK": Noun(()),
        "WALL": Noun(()),
        "ROCK": Noun(()),
        "COMPUTER": Noun (()),
        "BUG": Noun(()),
        "FLAG": Noun(()),
        "YOU": Property(()),
        "STOP": Property(()),
        "PUSH": Property (()),
        "PULL": Property(()),
        "DEFEAT": Property(()),
        "WIN": Property(()),
        "snek": graphical_object(()),
        "flag": graphical_object(()),
        "rock": graphical_object(()),
        "wall": graphical_object(()),
        "bug": graphical_object(()),
        "computer": graphical_object(()),
        "inplay": set()

        }
    #rule_list = ["WALL IS STOP", "ROCK IS PUSH", "COMPUTER IS PULL", "BUG IS DEFEAT", "FLAG IS WIN" ]
    rule_list = []
    for r, row in enumerate(game_desc):
        for c, column in enumerate(row):
            if column != []:
                for col in column:
                    object_dict[col].locations.append((r,c))
                    object_dict["inplay"].add(col)
    return object_dict, rule_list
    
                    #evaluate c
##                    if column == "IS":
##                        object_dict[column].locations.append = Verb((r, c))
##                    elif column == "AND":
##                        object_dict[column] = Conjunction((r, c))
##                    elif column in ["SNEK", "WALL", "ROCK", "COMPUTER", "BUG", "FLAG"]:
##                        object_dict[column] = Noun((r,c))
##                    elif column in ["YOU", "STOP", "PUSH", "PULL", "DEFEAT", "WIN"]:
##                        object_dict[column] = Property((r,c))
##                    elif column in ["snek", "flag", "rock", "wall", "bug",  "computer"]:
##                        object_dict[column] = graphical_object((r,c))
testenv = game([[]])




def new_game(level_description):
    """
    Given a description of a game state, create and return a game
    representation of your choice.

    The given description is a list of lists of lists of strs, where UPPERCASE
    strings represent word objects and lowercase strings represent regular
    objects (as described in the lab writeup).

    For example, a valid level_description is:

    [
        [[], ['snek'], []],
        [['SNEK'], ['IS'], ['YOU']],
    ]

    The exact choice of representation is up to you; but note that what you
    return will be used as input to the other functions.
    """
    #print("*******/n ", level_description)
    G = game(level_description)
    G.update_rules()
    G.evaluate_rules()
    return G #return a new game containing dimentions, objects and rules
    
    


def step_game(game, direction):
    """
    Given a game representation (as returned from new_game), modify that game
    representation in-place according to one step of the game.  The user's
    input is given by direction, which is one of the following:
    {'up', 'down', 'left', 'right'}.

    step_game should return a Boolean: True if the game has been won after
    updating the state, and False otherwise.
    """
    
    old_loc = []
    for Y in game.you:
        old_loc+=game.objects[Y].locations.copy()

    seen = game.update_state(direction)
    new_loc = []
    for Y in game.you:
        new_loc+=game.objects[Y].locations.copy()

    success = game.update_pull(set(old_loc)-set(new_loc), direction, True, seen)
    game.pull_extended(success, direction)

    
    #[print(row) for row in dump_game(game)]
    game.update_rules()
    game.evaluate_rules(True)
    game.determine_defeat()
    print("*********")
    
##    Move objects according to the movement-based properties ("YOU", "STOP", "PUSH", "PULL")
    
##    Parse the text objects and update the rules accordingly
    
##    Adjust object types based on rules whose predicate is a noun

    
    return game.haswon()
    


def dump_game(game):
    """
    Given a game representation (as returned from new_game), convert it back
    into a level description that would be a suitable input to new_game.

    This function is used by the GUI and tests to see what your game
    implementation has done, and it can also serve as a rudimentary way to
    print out the current state of your game for testing and debugging on your
    own.
    """
    emptyboard = [ [ [] for i in range(game.width)] for j in range (game.height)]
    for obtype in game.objects["inplay"]:
        given_locations = game.objects[obtype].locations #should now be a list
        for locate in given_locations:

            emptyboard[locate[0]][locate[1]].append(obtype)
    #print(emptyboard)
    return emptyboard
